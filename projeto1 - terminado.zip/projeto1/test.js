app.put('/Product/:id/images' ,function(request, response){
    var newId = request.params.id;
    var newImage = request.body.images;
    var newImageActual = request.query.images;
    /*body:
    {
        "images": "https://clickhole.com/wp-content/uploads/2019/10/s6m9aztvq2sehmdceup3.jpg"
    }
    */
    connection.query('UPDATE Product SET images = CONCAT(images,";",newImage) WHERE id = ?', [newId], function(err,rows,fields){
        response.send("New image: "  + newImage + " / Old image "+ newImageActual);
    }) 
})
