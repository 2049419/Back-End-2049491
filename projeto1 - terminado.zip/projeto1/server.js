const express = require('express');
const mysql = require('mysql');
const { SET } = require('mysql/lib/protocol/constants/types');
const app = express();
const port = 8000;
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

var server = app.listen(port, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("SERVER RUNNING")
});


//SQL
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto1'
})

//A.a)
app.get('/Product', function (request, response) { //localhost:8000/Product/
    connection.query('SELECT * FROM Product', function (err, rows, fields) {
        response.send(rows);
    })
})

//A.b)
app.post('/Product', function (request, response) { //localhost:8000/Product/
    var newProd = request.body;
    /*body:
    {
        "seller_id": 2,
        "title": "new product",
        "description_": "a new product from body",
        "price": 2.99,
        "url": "https://www.sapo.pt/",
        "views_": 99,
        "images": "https://www.sapo.pt/assets/img/homepage-sapo/facebook.jpg",
        "comments_": "this is a comment",
        "tags": "sapo"
    }
    */
    connection.query('INSERT INTO Product SET ?', [newProd], function (err, rows, fields) {
        response.send("Product inserted with id: " + rows.insertId);
    })
})

//A.c)
app.get('/Product/seller', function (request, response) { //localhost:8000/Product/seller?seller_id=1
    var newSeller = request.query.seller_id;
    connection.query('SELECT * FROM Product WHERE seller_id = ? ', [newSeller], function (err, rows, fields) {
        response.send(rows);
    })
})

//A.d)
app.put('/Product/check/:id', function (request, response) { //localhost:8000/Product/
    var newId = request.params.id;
    connection.query('UPDATE Product SET views_ = views_ + 1 WHERE Product.id = ?', [newId], function (err, rows, fields) {
        if (rows.affectedRows != 0) {
            connection.query('SELECT * FROM Product WHERE id = ? ', [newId], function (err, rows, fields) {
                response.send("Views: " + rows[0].views_);
            })
        }
        else {
            response.send("The ID " + newId + " didn't respond.");
        }
    })
})

//A.e)
app.get('/Product/tags', function (request, response) { //localhost:8000/Product/tags?tags=duck
    var newTags = request.query.tags;
    connection.query('SELECT * FROM Product WHERE Product.tags = ?', [newTags], function (err, rows, fields) {
        if (rows.length < 1) {
            response.send("The tag " + newTags + " does not exist.")
        } else {
            connection.query('SELECT * FROM Product WHERE tags LIKE ? ', [newTags], function (err, rows, fields) {
                response.send(rows);
            })
        }
    })
})

//B.a)
app.get('/Product/id', function (request, response) { //localhost:8000/Product/id?id=1
    var newId = request.query.id;
    connection.query('SELECT * FROM Product WHERE id = ? ', [newId], function (err, rows, fields) {
        response.send(rows);
    })
})

//B.b)
app.delete('/Product/:id', function (request, response) { //localhost:8000/Product/1
    var newId = request.params.id;
    connection.query('SELECT * FROM Product WHERE Product.id = ?', [newId], function (err, rows, fields) {
        if (rows.length < 1) {
            response.send('Product does not exist in the database.');
        } else {
            connection.query('DELETE FROM Product WHERE id = ?;', [newId], function (err, rows, fields) {
                response.send("Product with id " + newId + "was deleted.");
            })
        }
    })
})

//B.c)
app.put('/Product/:id', function (request, response) { //localhost:8000/Product/1
    var newId = request.params.id;
    var newImage = request.body.images;
    /*body:
    {
        "images": "https://clickhole.com/wp-content/uploads/2019/10/s6m9aztvq2sehmdceup3.jpg"
    }
    */
    connection.query('SELECT * FROM Product WHERE Product.id = ?', [newId], function (err, rows, fields) {
        if (rows.length < 1) {
            response.send('Product does not exist in the database.');
        } else {
            connection.query('SELECT images FROM Product WHERE id = ?', [newId], (err, rows, field) => {
                var newImage_v2 = newImage + " , " + rows[0].images;
                connection.query('UPDATE Product SET images = ? WHERE id = ?', [newImage_v2, newId], (err, rows, field) => {
                    response.send('Images updated successfully.');
                })
            })
        }
    })
})

//B.d)
app.put('/Product/check/id', (request, response) => { //localhost:8000/Product/check/id?id=1
    var newId = request.query.id;
    var newComment = request.body.comments_;
    /*body:
    {
        "comments_": "new comment 1"
    }
    */
    connection.query('SELECT * FROM Product WHERE Product.id = ?', [newId], function (err, rows, fields) {
        if (rows.length < 1) {
            response.send('Product does not exist in the database.');
        } else {
            connection.query('SELECT comments_ FROM Product WHERE id = ?', [newId], (err, rows, field) => {
                var newComment_v2 = newComment + " , " + rows[0].comments_;
                connection.query('UPDATE Product SET comments_ = ? WHERE id = ?', [newComment_v2, newId], (err, rows, field) => {
                    response.send('Comments updated successfully.');
                })
            })
        }
    })
})


//B.e)
app.get('/Product/sort', function (request, response) { //localhost:8000/Product/sort
    connection.query("SELECT * FROM Product", function (err, rows, fields) {
        rows.sort(function (a, b) {
            return b.views_ - a.views_;
        });
        response.send(rows);
    })
})